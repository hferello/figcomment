"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/dayjs/dayjs.min.js
  var require_dayjs_min = __commonJS({
    "node_modules/dayjs/dayjs.min.js"(exports, module) {
      !(function(t, e) {
        "object" == typeof exports && "undefined" != typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define(e) : (t = "undefined" != typeof globalThis ? globalThis : t || self).dayjs = e();
      })(exports, (function() {
        "use strict";
        var t = 1e3, e = 6e4, n = 36e5, r = "millisecond", i = "second", s = "minute", u = "hour", a = "day", o = "week", c = "month", f = "quarter", h = "year", d = "date", l = "Invalid Date", $ = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/, y = /\[([^\]]+)]|YYYY|YY|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g, M = { name: "en", weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"), months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"), ordinal: function(t2) {
          var e2 = ["th", "st", "nd", "rd"], n2 = t2 % 100;
          return "[" + t2 + (e2[(n2 - 20) % 10] || e2[n2] || e2[0]) + "]";
        } }, m = function(t2, e2, n2) {
          var r2 = String(t2);
          return !r2 || r2.length >= e2 ? t2 : "" + Array(e2 + 1 - r2.length).join(n2) + t2;
        }, v = { s: m, z: function(t2) {
          var e2 = -t2.utcOffset(), n2 = Math.abs(e2), r2 = Math.floor(n2 / 60), i2 = n2 % 60;
          return (e2 <= 0 ? "+" : "-") + m(r2, 2, "0") + ":" + m(i2, 2, "0");
        }, m: function t2(e2, n2) {
          if (e2.date() < n2.date()) return -t2(n2, e2);
          var r2 = 12 * (n2.year() - e2.year()) + (n2.month() - e2.month()), i2 = e2.clone().add(r2, c), s2 = n2 - i2 < 0, u2 = e2.clone().add(r2 + (s2 ? -1 : 1), c);
          return +(-(r2 + (n2 - i2) / (s2 ? i2 - u2 : u2 - i2)) || 0);
        }, a: function(t2) {
          return t2 < 0 ? Math.ceil(t2) || 0 : Math.floor(t2);
        }, p: function(t2) {
          return { M: c, y: h, w: o, d: a, D: d, h: u, m: s, s: i, ms: r, Q: f }[t2] || String(t2 || "").toLowerCase().replace(/s$/, "");
        }, u: function(t2) {
          return void 0 === t2;
        } }, g = "en", D = {};
        D[g] = M;
        var p = "$isDayjsObject", S = function(t2) {
          return t2 instanceof _ || !(!t2 || !t2[p]);
        }, w = function t2(e2, n2, r2) {
          var i2;
          if (!e2) return g;
          if ("string" == typeof e2) {
            var s2 = e2.toLowerCase();
            D[s2] && (i2 = s2), n2 && (D[s2] = n2, i2 = s2);
            var u2 = e2.split("-");
            if (!i2 && u2.length > 1) return t2(u2[0]);
          } else {
            var a2 = e2.name;
            D[a2] = e2, i2 = a2;
          }
          return !r2 && i2 && (g = i2), i2 || !r2 && g;
        }, O = function(t2, e2) {
          if (S(t2)) return t2.clone();
          var n2 = "object" == typeof e2 ? e2 : {};
          return n2.date = t2, n2.args = arguments, new _(n2);
        }, b = v;
        b.l = w, b.i = S, b.w = function(t2, e2) {
          return O(t2, { locale: e2.$L, utc: e2.$u, x: e2.$x, $offset: e2.$offset });
        };
        var _ = (function() {
          function M2(t2) {
            this.$L = w(t2.locale, null, true), this.parse(t2), this.$x = this.$x || t2.x || {}, this[p] = true;
          }
          var m2 = M2.prototype;
          return m2.parse = function(t2) {
            this.$d = (function(t3) {
              var e2 = t3.date, n2 = t3.utc;
              if (null === e2) return /* @__PURE__ */ new Date(NaN);
              if (b.u(e2)) return /* @__PURE__ */ new Date();
              if (e2 instanceof Date) return new Date(e2);
              if ("string" == typeof e2 && !/Z$/i.test(e2)) {
                var r2 = e2.match($);
                if (r2) {
                  var i2 = r2[2] - 1 || 0, s2 = (r2[7] || "0").substring(0, 3);
                  return n2 ? new Date(Date.UTC(r2[1], i2, r2[3] || 1, r2[4] || 0, r2[5] || 0, r2[6] || 0, s2)) : new Date(r2[1], i2, r2[3] || 1, r2[4] || 0, r2[5] || 0, r2[6] || 0, s2);
                }
              }
              return new Date(e2);
            })(t2), this.init();
          }, m2.init = function() {
            var t2 = this.$d;
            this.$y = t2.getFullYear(), this.$M = t2.getMonth(), this.$D = t2.getDate(), this.$W = t2.getDay(), this.$H = t2.getHours(), this.$m = t2.getMinutes(), this.$s = t2.getSeconds(), this.$ms = t2.getMilliseconds();
          }, m2.$utils = function() {
            return b;
          }, m2.isValid = function() {
            return !(this.$d.toString() === l);
          }, m2.isSame = function(t2, e2) {
            var n2 = O(t2);
            return this.startOf(e2) <= n2 && n2 <= this.endOf(e2);
          }, m2.isAfter = function(t2, e2) {
            return O(t2) < this.startOf(e2);
          }, m2.isBefore = function(t2, e2) {
            return this.endOf(e2) < O(t2);
          }, m2.$g = function(t2, e2, n2) {
            return b.u(t2) ? this[e2] : this.set(n2, t2);
          }, m2.unix = function() {
            return Math.floor(this.valueOf() / 1e3);
          }, m2.valueOf = function() {
            return this.$d.getTime();
          }, m2.startOf = function(t2, e2) {
            var n2 = this, r2 = !!b.u(e2) || e2, f2 = b.p(t2), l2 = function(t3, e3) {
              var i2 = b.w(n2.$u ? Date.UTC(n2.$y, e3, t3) : new Date(n2.$y, e3, t3), n2);
              return r2 ? i2 : i2.endOf(a);
            }, $2 = function(t3, e3) {
              return b.w(n2.toDate()[t3].apply(n2.toDate("s"), (r2 ? [0, 0, 0, 0] : [23, 59, 59, 999]).slice(e3)), n2);
            }, y2 = this.$W, M3 = this.$M, m3 = this.$D, v2 = "set" + (this.$u ? "UTC" : "");
            switch (f2) {
              case h:
                return r2 ? l2(1, 0) : l2(31, 11);
              case c:
                return r2 ? l2(1, M3) : l2(0, M3 + 1);
              case o:
                var g2 = this.$locale().weekStart || 0, D2 = (y2 < g2 ? y2 + 7 : y2) - g2;
                return l2(r2 ? m3 - D2 : m3 + (6 - D2), M3);
              case a:
              case d:
                return $2(v2 + "Hours", 0);
              case u:
                return $2(v2 + "Minutes", 1);
              case s:
                return $2(v2 + "Seconds", 2);
              case i:
                return $2(v2 + "Milliseconds", 3);
              default:
                return this.clone();
            }
          }, m2.endOf = function(t2) {
            return this.startOf(t2, false);
          }, m2.$set = function(t2, e2) {
            var n2, o2 = b.p(t2), f2 = "set" + (this.$u ? "UTC" : ""), l2 = (n2 = {}, n2[a] = f2 + "Date", n2[d] = f2 + "Date", n2[c] = f2 + "Month", n2[h] = f2 + "FullYear", n2[u] = f2 + "Hours", n2[s] = f2 + "Minutes", n2[i] = f2 + "Seconds", n2[r] = f2 + "Milliseconds", n2)[o2], $2 = o2 === a ? this.$D + (e2 - this.$W) : e2;
            if (o2 === c || o2 === h) {
              var y2 = this.clone().set(d, 1);
              y2.$d[l2]($2), y2.init(), this.$d = y2.set(d, Math.min(this.$D, y2.daysInMonth())).$d;
            } else l2 && this.$d[l2]($2);
            return this.init(), this;
          }, m2.set = function(t2, e2) {
            return this.clone().$set(t2, e2);
          }, m2.get = function(t2) {
            return this[b.p(t2)]();
          }, m2.add = function(r2, f2) {
            var d2, l2 = this;
            r2 = Number(r2);
            var $2 = b.p(f2), y2 = function(t2) {
              var e2 = O(l2);
              return b.w(e2.date(e2.date() + Math.round(t2 * r2)), l2);
            };
            if ($2 === c) return this.set(c, this.$M + r2);
            if ($2 === h) return this.set(h, this.$y + r2);
            if ($2 === a) return y2(1);
            if ($2 === o) return y2(7);
            var M3 = (d2 = {}, d2[s] = e, d2[u] = n, d2[i] = t, d2)[$2] || 1, m3 = this.$d.getTime() + r2 * M3;
            return b.w(m3, this);
          }, m2.subtract = function(t2, e2) {
            return this.add(-1 * t2, e2);
          }, m2.format = function(t2) {
            var e2 = this, n2 = this.$locale();
            if (!this.isValid()) return n2.invalidDate || l;
            var r2 = t2 || "YYYY-MM-DDTHH:mm:ssZ", i2 = b.z(this), s2 = this.$H, u2 = this.$m, a2 = this.$M, o2 = n2.weekdays, c2 = n2.months, f2 = n2.meridiem, h2 = function(t3, n3, i3, s3) {
              return t3 && (t3[n3] || t3(e2, r2)) || i3[n3].slice(0, s3);
            }, d2 = function(t3) {
              return b.s(s2 % 12 || 12, t3, "0");
            }, $2 = f2 || function(t3, e3, n3) {
              var r3 = t3 < 12 ? "AM" : "PM";
              return n3 ? r3.toLowerCase() : r3;
            };
            return r2.replace(y, (function(t3, r3) {
              return r3 || (function(t4) {
                switch (t4) {
                  case "YY":
                    return String(e2.$y).slice(-2);
                  case "YYYY":
                    return b.s(e2.$y, 4, "0");
                  case "M":
                    return a2 + 1;
                  case "MM":
                    return b.s(a2 + 1, 2, "0");
                  case "MMM":
                    return h2(n2.monthsShort, a2, c2, 3);
                  case "MMMM":
                    return h2(c2, a2);
                  case "D":
                    return e2.$D;
                  case "DD":
                    return b.s(e2.$D, 2, "0");
                  case "d":
                    return String(e2.$W);
                  case "dd":
                    return h2(n2.weekdaysMin, e2.$W, o2, 2);
                  case "ddd":
                    return h2(n2.weekdaysShort, e2.$W, o2, 3);
                  case "dddd":
                    return o2[e2.$W];
                  case "H":
                    return String(s2);
                  case "HH":
                    return b.s(s2, 2, "0");
                  case "h":
                    return d2(1);
                  case "hh":
                    return d2(2);
                  case "a":
                    return $2(s2, u2, true);
                  case "A":
                    return $2(s2, u2, false);
                  case "m":
                    return String(u2);
                  case "mm":
                    return b.s(u2, 2, "0");
                  case "s":
                    return String(e2.$s);
                  case "ss":
                    return b.s(e2.$s, 2, "0");
                  case "SSS":
                    return b.s(e2.$ms, 3, "0");
                  case "Z":
                    return i2;
                }
                return null;
              })(t3) || i2.replace(":", "");
            }));
          }, m2.utcOffset = function() {
            return 15 * -Math.round(this.$d.getTimezoneOffset() / 15);
          }, m2.diff = function(r2, d2, l2) {
            var $2, y2 = this, M3 = b.p(d2), m3 = O(r2), v2 = (m3.utcOffset() - this.utcOffset()) * e, g2 = this - m3, D2 = function() {
              return b.m(y2, m3);
            };
            switch (M3) {
              case h:
                $2 = D2() / 12;
                break;
              case c:
                $2 = D2();
                break;
              case f:
                $2 = D2() / 3;
                break;
              case o:
                $2 = (g2 - v2) / 6048e5;
                break;
              case a:
                $2 = (g2 - v2) / 864e5;
                break;
              case u:
                $2 = g2 / n;
                break;
              case s:
                $2 = g2 / e;
                break;
              case i:
                $2 = g2 / t;
                break;
              default:
                $2 = g2;
            }
            return l2 ? $2 : b.a($2);
          }, m2.daysInMonth = function() {
            return this.endOf(c).$D;
          }, m2.$locale = function() {
            return D[this.$L];
          }, m2.locale = function(t2, e2) {
            if (!t2) return this.$L;
            var n2 = this.clone(), r2 = w(t2, e2, true);
            return r2 && (n2.$L = r2), n2;
          }, m2.clone = function() {
            return b.w(this.$d, this);
          }, m2.toDate = function() {
            return new Date(this.valueOf());
          }, m2.toJSON = function() {
            return this.isValid() ? this.toISOString() : null;
          }, m2.toISOString = function() {
            return this.$d.toISOString();
          }, m2.toString = function() {
            return this.$d.toUTCString();
          }, M2;
        })(), Y = _.prototype;
        return O.prototype = Y, [["$ms", r], ["$s", i], ["$m", s], ["$H", u], ["$W", a], ["$M", c], ["$y", h], ["$D", d]].forEach((function(t2) {
          Y[t2[1]] = function(e2) {
            return this.$g(e2, t2[0], t2[1]);
          };
        })), O.extend = function(t2, e2) {
          return t2.$i || (t2(e2, _, O), t2.$i = true), O;
        }, O.locale = w, O.isDayjs = S, O.unix = function(t2) {
          return O(1e3 * t2);
        }, O.en = D[g], O.Ls = D, O.p = {}, O;
      }));
    }
  });

  // code.ts
  var import_dayjs = __toESM(require_dayjs_min());

  // classify-response-guard.ts
  function isClassifyResponse(value) {
    if (typeof value !== "object" || value === null) {
      return false;
    }
    const record = value;
    if (!Array.isArray(record.rows) || typeof record.meta !== "object" || record.meta === null) {
      return false;
    }
    const meta = record.meta;
    if (meta.mode !== "live" && meta.mode !== "mock" && meta.mode !== "fallback" || meta.sort_method !== "heuristic" && meta.sort_method !== "ai" || meta.provider !== null && meta.provider !== "openai" && meta.provider !== "gemini" && meta.provider !== "anthropic" || typeof meta.latency_ms !== "number") {
      return false;
    }
    return record.rows.every((row) => isRow(row));
  }
  function isRow(value) {
    if (typeof value !== "object" || value === null) {
      return false;
    }
    const row = value;
    return typeof row.person === "string" && typeof row.feedback === "string" && (row.type === "Thoughts" || row.type === "Suggestion" || row.type === "Action" || row.type === "Red flag" || row.type === "Note") && (row.critique_lens === "Low - Visual design" || row.critique_lens === "Low - Interaction design" || row.critique_lens === "Medium - Flow and information design" || row.critique_lens === "High - Underlying model, business rules and logic" || row.critique_lens === "High - User need/problem" || row.critique_lens === "High - Business opportunity/problem");
  }

  // figma-file-url.ts
  var FIGMA_HOSTS = /* @__PURE__ */ new Set(["figma.com", "www.figma.com"]);
  function parseFigmaFileUrl(input) {
    const parsed = parseHttpsUrl(input.trim());
    if (!parsed) {
      throw new Error("Paste a valid Figma file URL.");
    }
    if (!FIGMA_HOSTS.has(parsed.hostname)) {
      throw new Error("URL must use figma.com.");
    }
    const parts = parsed.pathname.split("/").filter(Boolean);
    if (parts.length < 2) {
      throw new Error("Paste a Figma design file URL.");
    }
    if (parts[0] === "design" && parts[2] === "branch" && parts[3]) {
      return { file_key: parts[3] };
    }
    if (parts[0] === "design" && parts[1]) {
      return { file_key: parts[1] };
    }
    if (parts[0] === "file" && parts[1]) {
      return { file_key: parts[1] };
    }
    if (parts[0] === "proto" && parts[1]) {
      return { file_key: parts[1] };
    }
    const branch_index = parts.indexOf("branch");
    if (branch_index >= 0 && parts[branch_index + 1]) {
      return { file_key: parts[branch_index + 1] };
    }
    throw new Error("Could not extract the file key from this URL.");
  }
  function parseHttpsUrl(value) {
    const match = value.match(/^https:\/\/([^/?#]+)(\/[^?#]*)?/i);
    if (!match) {
      return null;
    }
    const hostname = match[1]?.toLowerCase() ?? "";
    const pathname = match[2] ?? "/";
    return { hostname, pathname };
  }

  // code.ts
  function figjamStickyColor(red, green, blue) {
    return { r: red / 255, g: green / 255, b: blue / 255 };
  }
  var FIGJAM_STICKY = {
    yellow: figjamStickyColor(255, 226, 153),
    blue: figjamStickyColor(168, 218, 255),
    green: figjamStickyColor(179, 239, 189),
    teal: figjamStickyColor(179, 244, 239),
    violet: figjamStickyColor(211, 189, 255),
    pink: figjamStickyColor(255, 168, 219),
    red: figjamStickyColor(255, 184, 168),
    orange: figjamStickyColor(255, 211, 168)
  };
  var LENS_DISPLAY_ORDER = [
    "Low - Visual design",
    "Low - Interaction design",
    "Medium - Flow and information design",
    "High - Underlying model, business rules and logic",
    "High - User need/problem",
    "High - Business opportunity/problem"
  ];
  var THEME_STYLES = {
    "Low - Visual design": {
      section_bg: { r: 0.98, g: 0.96, b: 0.88 },
      header_accent: { r: 0.95, g: 0.78, b: 0.2 },
      note_fill: FIGJAM_STICKY.yellow
    },
    "Low - Interaction design": {
      section_bg: { r: 0.93, g: 0.96, b: 1 },
      header_accent: { r: 0.22, g: 0.56, b: 0.96 },
      note_fill: FIGJAM_STICKY.blue
    },
    "Medium - Flow and information design": {
      section_bg: { r: 0.93, g: 0.98, b: 0.94 },
      header_accent: { r: 0.18, g: 0.66, b: 0.45 },
      note_fill: FIGJAM_STICKY.green
    },
    "High - Underlying model, business rules and logic": {
      section_bg: { r: 0.96, g: 0.93, b: 0.99 },
      header_accent: { r: 0.58, g: 0.33, b: 0.84 },
      note_fill: FIGJAM_STICKY.violet
    },
    "High - User need/problem": {
      section_bg: { r: 0.99, g: 0.94, b: 0.94 },
      header_accent: { r: 0.86, g: 0.3, b: 0.33 },
      note_fill: FIGJAM_STICKY.red
    },
    "High - Business opportunity/problem": {
      section_bg: { r: 0.98, g: 0.94, b: 0.9 },
      header_accent: { r: 0.86, g: 0.55, b: 0.18 },
      note_fill: FIGJAM_STICKY.orange
    }
  };
  var DEFAULT_THEME_STYLE = {
    section_bg: { r: 0.97, g: 0.97, b: 0.97 },
    header_accent: { r: 0.45, g: 0.45, b: 0.45 },
    note_fill: FIGJAM_STICKY.yellow
  };
  var FEEDBACK_TYPE_EMOJI = {
    Thoughts: "\u{1F4AD}",
    Suggestion: "\u{1F4A1}",
    Action: "\u2705",
    "Red flag": "\u{1F6A9}",
    Note: "\u{1F4DD}"
  };
  var FIGJAM_STICKY_DROP_SHADOW = {
    type: "DROP_SHADOW",
    color: { r: 0, g: 0, b: 0, a: 0.06 },
    offset: { x: 0, y: 3 },
    radius: 12,
    spread: 0,
    visible: true,
    blendMode: "NORMAL"
  };
  var CLASSIFY_API_URL = "https://comment-sort.vercel.app/api/classify";
  var PLUGIN_TOKEN_STORAGE_KEY = "plugin_token";
  var FILE_URL_STORAGE_KEY = "file_url";
  var SORT_METHOD_STORAGE_KEY = "sort_method";
  var FONT_REGULAR = { family: "Inter", style: "Regular" };
  var FONT_BOLD = { family: "Inter", style: "Bold" };
  var PLUGIN_UI_WIDTH = 360;
  var PLUGIN_UI_CONNECT_HEIGHT = 330;
  figma.showUI(__html__, {
    width: PLUGIN_UI_WIDTH,
    height: PLUGIN_UI_CONNECT_HEIGHT
  });
  void bootstrapAuthState();
  figma.ui.onmessage = async (message) => {
    if (!isUiMessage(message)) {
      return;
    }
    if (message.type === "save_token") {
      await savePluginToken(message.plugin_token);
      return;
    }
    if (message.type === "save_settings") {
      await savePluginSettings(message.file_url, message.sort_method);
      return;
    }
    if (message.type === "clear_token") {
      await clearPluginToken();
      return;
    }
    if (message.type === "open_external") {
      openExternal(message.href);
      return;
    }
    if (message.type === "resize_ui") {
      figma.ui.resize(PLUGIN_UI_WIDTH, message.height);
      return;
    }
    await runAnalysis(message.output_format);
  };
  async function runAnalysis(output_format) {
    let current_step = "initializing";
    try {
      current_step = "checking_file_context";
      postStatus("\u{1F50D} Parsing file URL...");
      const file_url = await getStoredFileUrl();
      if (!file_url) {
        throw new Error("Paste a Figma file URL before running analysis.");
      }
      const { file_key } = parseFigmaFileUrl(file_url);
      const sort_method = await getStoredSortMethod();
      const plugin_token = await getStoredPluginToken();
      if (!plugin_token) {
        throw new Error(
          "Connect your plugin token first. Paste it from your web profile."
        );
      }
      current_step = "requesting_classification";
      postStatus("\u{1F920} Herding comments...");
      const classify_response = await fetchClassification(
        file_key,
        plugin_token,
        sort_method
      );
      if (classify_response.rows.length === 0) {
        throw new Error("\u{1F997} Crickets. This file has no comments to classify.");
      }
      current_step = "drawing_output";
      postStatus(`\u{1F527} Assembling your ${output_format.replace("_", " ")} like IKEA furniture...`);
      if (output_format === "csv") {
        exportCsv(classify_response.rows);
        postComplete(
          `\u{1F389} Boom! ${classify_response.rows.length} rows wrangled into a CSV.`
        );
        return;
      }
      const output_node = output_format === "sticky_notes" ? await drawStickyNotes(classify_response.rows) : await drawTable(classify_response.rows);
      figma.currentPage.selection = [output_node];
      figma.viewport.scrollAndZoomIntoView([output_node]);
      const output_label = output_format === "sticky_notes" ? "sticky note sections" : "table rows";
      postComplete(
        `\u{1F389} Boom! ${classify_response.rows.length} ${output_label} served up.`
      );
    } catch (error) {
      const message = formatUnknownError(error);
      console.error("[runAnalysis] error", {
        current_step,
        error
      });
      figma.ui.postMessage({ type: "error", message });
    }
  }
  async function fetchClassification(file_key, plugin_token, sort_method) {
    let response;
    try {
      response = await fetch(CLASSIFY_API_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${plugin_token}`
        },
        body: JSON.stringify({ file_key, sort_method })
      });
    } catch {
      throw new Error(
        "Could not reach Comment Sort. Check your connection and try again."
      );
    }
    if (!response.ok) {
      const body_text = await response.text();
      const backend_message = formatBackendErrorMessage(body_text, response.status);
      throw new Error(backend_message);
    }
    const payload = await response.json();
    if (!isClassifyResponse(payload)) {
      throw new Error("Backend response shape is invalid.");
    }
    return payload;
  }
  async function drawTable(rows) {
    await figma.loadFontAsync(FONT_REGULAR);
    await figma.loadFontAsync(FONT_BOLD);
    const table_frame = createLayoutFrame();
    table_frame.name = "Comment Sort Table";
    table_frame.layoutMode = "VERTICAL";
    table_frame.primaryAxisSizingMode = "AUTO";
    table_frame.counterAxisSizingMode = "AUTO";
    table_frame.itemSpacing = 0;
    table_frame.paddingLeft = 0;
    table_frame.paddingRight = 0;
    table_frame.paddingTop = 0;
    table_frame.paddingBottom = 0;
    table_frame.fills = [{ type: "SOLID", color: { r: 1, g: 1, b: 1 } }];
    table_frame.strokes = [{ type: "SOLID", color: { r: 0.86, g: 0.88, b: 0.91 } }];
    table_frame.strokeWeight = 1;
    table_frame.cornerRadius = 8;
    const header_row = createRow(
      ["Person", "Feedback", "Type", "Critique Lens"],
      true
    );
    table_frame.appendChild(header_row);
    for (const row of rows) {
      const row_node = createRow(
        [row.person, row.feedback, formatFeedbackType(row.type), formatCritiqueLens(row.critique_lens)],
        false
      );
      table_frame.appendChild(row_node);
    }
    const center = figma.viewport.center;
    table_frame.x = center.x - table_frame.width / 2;
    table_frame.y = center.y - table_frame.height / 2;
    figma.currentPage.appendChild(table_frame);
    return table_frame;
  }
  async function drawStickyNotes(rows) {
    await figma.loadFontAsync(FONT_REGULAR);
    await figma.loadFontAsync(FONT_BOLD);
    const board_frame = createLayoutFrame();
    board_frame.name = "Comment Sort Sticky Notes";
    const grouped_rows = groupRowsByLens(rows);
    const board_width = getStickyNotesBoardWidth(
      getMaxCommentsPerSection(grouped_rows)
    );
    board_frame.layoutMode = "VERTICAL";
    board_frame.resize(board_width, 1);
    board_frame.primaryAxisSizingMode = "AUTO";
    board_frame.counterAxisSizingMode = "FIXED";
    board_frame.itemSpacing = 24;
    board_frame.paddingLeft = 24;
    board_frame.paddingRight = 24;
    board_frame.paddingTop = 24;
    board_frame.paddingBottom = 24;
    board_frame.fills = [{ type: "SOLID", color: { r: 0.98, g: 0.99, b: 1 } }];
    board_frame.cornerRadius = 12;
    for (const lens of LENS_DISPLAY_ORDER) {
      const section_rows = grouped_rows.get(lens);
      if (!section_rows || section_rows.length === 0) {
        continue;
      }
      const theme_style = getThemeStyle(lens);
      const theme_label = formatCritiqueLens(lens);
      const section_frame = createLayoutFrame();
      section_frame.name = `Theme: ${theme_label}`;
      section_frame.layoutMode = "VERTICAL";
      section_frame.primaryAxisSizingMode = "AUTO";
      section_frame.counterAxisSizingMode = "FIXED";
      section_frame.itemSpacing = 16;
      section_frame.paddingLeft = 16;
      section_frame.paddingRight = 16;
      section_frame.paddingTop = 16;
      section_frame.paddingBottom = 16;
      section_frame.fills = [
        { type: "SOLID", color: theme_style.section_bg }
      ];
      section_frame.cornerRadius = 10;
      const header_frame = createLayoutFrame();
      header_frame.name = "Theme header";
      header_frame.layoutMode = "VERTICAL";
      header_frame.primaryAxisSizingMode = "AUTO";
      header_frame.counterAxisSizingMode = "AUTO";
      header_frame.itemSpacing = 6;
      header_frame.paddingLeft = 0;
      header_frame.paddingRight = 0;
      header_frame.paddingTop = 12;
      header_frame.paddingBottom = 12;
      header_frame.fills = [];
      header_frame.cornerRadius = 8;
      const title_node = createTextNode(theme_label, FONT_BOLD, 14, {
        r: 0.13,
        g: 0.16,
        b: 0.2
      });
      const summary_node = createTextNode(
        summarizeTheme(theme_label, section_rows),
        FONT_REGULAR,
        11,
        { r: 0.2, g: 0.24, b: 0.3 }
      );
      header_frame.appendChild(title_node);
      header_frame.appendChild(summary_node);
      summary_node.layoutSizingHorizontal = "FILL";
      section_frame.appendChild(header_frame);
      header_frame.layoutSizingHorizontal = "FILL";
      const comments_frame = createLayoutFrame();
      comments_frame.name = "Comments";
      comments_frame.layoutMode = "HORIZONTAL";
      comments_frame.primaryAxisSizingMode = "FIXED";
      comments_frame.counterAxisSizingMode = "AUTO";
      comments_frame.layoutWrap = "WRAP";
      comments_frame.itemSpacing = 16;
      comments_frame.counterAxisSpacing = 16;
      comments_frame.resize(board_width - 80, 1);
      comments_frame.fills = [];
      for (const row of section_rows) {
        const comment_card = createCommentCard(row, theme_style.note_fill);
        comments_frame.appendChild(comment_card);
        comment_card.layoutSizingVertical = "HUG";
      }
      section_frame.appendChild(comments_frame);
      comments_frame.layoutSizingHorizontal = "FILL";
      board_frame.appendChild(section_frame);
      section_frame.layoutSizingHorizontal = "FILL";
    }
    appendUnmappedLensSections(board_frame, grouped_rows);
    const center = figma.viewport.center;
    board_frame.x = center.x - board_frame.width / 2;
    board_frame.y = center.y - board_frame.height / 2;
    figma.currentPage.appendChild(board_frame);
    return board_frame;
  }
  function createCommentCard(row, card_fill) {
    const comment_frame = createLayoutFrame();
    comment_frame.name = "Comment";
    comment_frame.layoutMode = "VERTICAL";
    comment_frame.resize(150, 1);
    comment_frame.primaryAxisSizingMode = "AUTO";
    comment_frame.counterAxisSizingMode = "FIXED";
    comment_frame.itemSpacing = 6;
    comment_frame.paddingLeft = 12;
    comment_frame.paddingRight = 12;
    comment_frame.paddingTop = 12;
    comment_frame.paddingBottom = 12;
    comment_frame.fills = [{ type: "SOLID", color: card_fill }];
    comment_frame.cornerRadius = 0;
    comment_frame.effects = [FIGJAM_STICKY_DROP_SHADOW];
    const text_color = { r: 0.13, g: 0.16, b: 0.2 };
    const author_node = createTextNode(
      `${row.person} said`,
      FONT_BOLD,
      11,
      text_color
    );
    const feedback_node = createTextNode(row.feedback, FONT_REGULAR, 11, text_color);
    comment_frame.appendChild(author_node);
    comment_frame.appendChild(feedback_node);
    feedback_node.layoutSizingHorizontal = "FILL";
    return comment_frame;
  }
  function exportCsv(rows) {
    const csv_content = rowsToCsv(rows);
    const export_date = (0, import_dayjs.default)().format("YYYY-MM-DD");
    figma.ui.postMessage({
      type: "download_csv",
      csv: csv_content,
      filename: `comment-sort-export-${export_date}.csv`
    });
  }
  function rowsToCsv(rows) {
    const headers = ["Person", "Feedback", "Type", "Critique Lens"];
    const lines = rows.map(
      (row) => [
        escapeCsvField(row.person),
        escapeCsvField(row.feedback),
        escapeCsvField(row.type),
        escapeCsvField(formatCritiqueLens(row.critique_lens))
      ].join(",")
    );
    return [headers.join(","), ...lines].join("\n");
  }
  function escapeCsvField(value) {
    if (/[",\n\r]/.test(value)) {
      return `"${value.replace(/"/g, '""')}"`;
    }
    return value;
  }
  function groupRowsByLens(rows) {
    const grouped_rows = /* @__PURE__ */ new Map();
    for (const row of rows) {
      const existing_rows = grouped_rows.get(row.critique_lens) ?? [];
      existing_rows.push(row);
      grouped_rows.set(row.critique_lens, existing_rows);
    }
    return grouped_rows;
  }
  function appendUnmappedLensSections(board_frame, grouped_rows) {
    const known_lenses = new Set(LENS_DISPLAY_ORDER);
    for (const [lens, section_rows] of grouped_rows.entries()) {
      if (known_lenses.has(lens) || section_rows.length === 0) {
        continue;
      }
      const theme_style = getThemeStyle(lens);
      const theme_label = formatCritiqueLens(lens);
      const section_frame = createLayoutFrame();
      section_frame.name = `Theme: ${theme_label}`;
      section_frame.layoutMode = "VERTICAL";
      section_frame.primaryAxisSizingMode = "AUTO";
      section_frame.counterAxisSizingMode = "FIXED";
      section_frame.itemSpacing = 16;
      section_frame.paddingLeft = 16;
      section_frame.paddingRight = 16;
      section_frame.paddingTop = 16;
      section_frame.paddingBottom = 16;
      section_frame.fills = [
        { type: "SOLID", color: theme_style.section_bg }
      ];
      section_frame.cornerRadius = 10;
      const header_frame = createLayoutFrame();
      header_frame.layoutMode = "VERTICAL";
      header_frame.primaryAxisSizingMode = "AUTO";
      header_frame.counterAxisSizingMode = "AUTO";
      header_frame.itemSpacing = 6;
      header_frame.paddingLeft = 0;
      header_frame.paddingRight = 0;
      header_frame.paddingTop = 12;
      header_frame.paddingBottom = 12;
      header_frame.fills = [];
      header_frame.cornerRadius = 8;
      header_frame.appendChild(
        createTextNode(theme_label, FONT_BOLD, 14, { r: 0.13, g: 0.16, b: 0.2 })
      );
      const summary_node = createTextNode(
        summarizeTheme(theme_label, section_rows),
        FONT_REGULAR,
        11,
        { r: 0.2, g: 0.24, b: 0.3 }
      );
      header_frame.appendChild(summary_node);
      summary_node.layoutSizingHorizontal = "FILL";
      section_frame.appendChild(header_frame);
      header_frame.layoutSizingHorizontal = "FILL";
      const comments_frame = createLayoutFrame();
      comments_frame.name = "Comments";
      comments_frame.layoutMode = "HORIZONTAL";
      comments_frame.primaryAxisSizingMode = "FIXED";
      comments_frame.counterAxisSizingMode = "AUTO";
      comments_frame.layoutWrap = "WRAP";
      comments_frame.itemSpacing = 16;
      comments_frame.counterAxisSpacing = 16;
      comments_frame.resize(board_frame.width - 80, 1);
      comments_frame.fills = [];
      for (const row of section_rows) {
        const comment_card = createCommentCard(row, theme_style.note_fill);
        comments_frame.appendChild(comment_card);
        comment_card.layoutSizingVertical = "HUG";
      }
      section_frame.appendChild(comments_frame);
      comments_frame.layoutSizingHorizontal = "FILL";
      board_frame.appendChild(section_frame);
      section_frame.layoutSizingHorizontal = "FILL";
    }
  }
  function getMaxCommentsPerSection(grouped_rows) {
    let max_comments = 0;
    for (const section_rows of grouped_rows.values()) {
      max_comments = Math.max(max_comments, section_rows.length);
    }
    return max_comments;
  }
  function getStickyNotesBoardWidth(max_comments_per_section) {
    if (max_comments_per_section > 4) {
      return 750;
    }
    return 500;
  }
  function summarizeTheme(theme_label, rows) {
    const contributors = [...new Set(rows.map((row) => row.person))];
    const type_counts = rows.reduce((counts, row) => {
      const type_label = formatFeedbackType(row.type);
      counts[type_label] = (counts[type_label] ?? 0) + 1;
      return counts;
    }, {});
    const type_summary = Object.entries(type_counts).map(([type_label, count]) => `${count} ${type_label}`).join(", ");
    const contributor_summary = contributors.length === 1 ? contributors[0] : `${contributors.length} people (${contributors.slice(0, 3).join(", ")}${contributors.length > 3 ? ", ..." : ""})`;
    return `${rows.length} comment${rows.length === 1 ? "" : "s"} on ${theme_label.toLowerCase()} from ${contributor_summary}. Includes ${type_summary}.`;
  }
  function formatCritiqueLens(lens) {
    return lens.replace(/^(Low|Medium|High) - /, "");
  }
  function getThemeStyle(lens) {
    if (lens in THEME_STYLES) {
      return THEME_STYLES[lens];
    }
    return DEFAULT_THEME_STYLE;
  }
  function createLayoutFrame() {
    const frame = figma.createFrame();
    frame.clipsContent = false;
    return frame;
  }
  function createTextNode(value, font, font_size, color) {
    const text_node = figma.createText();
    text_node.fontName = font;
    text_node.fontSize = font_size;
    text_node.characters = value;
    text_node.textAutoResize = "HEIGHT";
    text_node.fills = [{ type: "SOLID", color }];
    return text_node;
  }
  function createRow(values, is_header) {
    const row_frame = createLayoutFrame();
    row_frame.layoutMode = "HORIZONTAL";
    row_frame.primaryAxisSizingMode = "AUTO";
    row_frame.counterAxisSizingMode = "AUTO";
    row_frame.itemSpacing = 0;
    row_frame.fills = [
      {
        type: "SOLID",
        color: is_header ? { r: 0.95, g: 0.97, b: 1 } : {
          r: 1,
          g: 1,
          b: 1
        }
      }
    ];
    row_frame.strokes = [{ type: "SOLID", color: { r: 0.9, g: 0.91, b: 0.94 } }];
    row_frame.strokeTopWeight = 0;
    row_frame.strokeRightWeight = 0;
    row_frame.strokeLeftWeight = 0;
    row_frame.strokeBottomWeight = 1;
    const cell_widths = [140, 400, 120, 320];
    values.forEach((value, index) => {
      const cell = createLayoutFrame();
      cell.layoutMode = "VERTICAL";
      cell.resize(cell_widths[index] ?? 120, 54);
      cell.primaryAxisSizingMode = "AUTO";
      cell.counterAxisSizingMode = "FIXED";
      cell.paddingLeft = 10;
      cell.paddingRight = 10;
      cell.paddingTop = 8;
      cell.paddingBottom = 8;
      cell.fills = [];
      cell.strokes = [{ type: "SOLID", color: { r: 0.9, g: 0.91, b: 0.94 } }];
      cell.strokeTopWeight = 0;
      cell.strokeBottomWeight = 0;
      cell.strokeLeftWeight = 0;
      cell.strokeRightWeight = index === values.length - 1 ? 0 : 1;
      const text_node = figma.createText();
      text_node.fontName = is_header ? FONT_BOLD : FONT_REGULAR;
      text_node.fontSize = is_header ? 12 : 11;
      text_node.characters = value;
      text_node.textAutoResize = "HEIGHT";
      text_node.fills = [{ type: "SOLID", color: { r: 0.13, g: 0.16, b: 0.2 } }];
      cell.appendChild(text_node);
      text_node.layoutSizingHorizontal = "FILL";
      row_frame.appendChild(cell);
      cell.layoutSizingVertical = "FILL";
    });
    return row_frame;
  }
  function formatFeedbackType(type) {
    return `${FEEDBACK_TYPE_EMOJI[type]} ${type}`;
  }
  function postStatus(message) {
    figma.ui.postMessage({ type: "status", message });
  }
  function postComplete(message) {
    figma.ui.postMessage({ type: "complete", message });
  }
  async function bootstrapAuthState() {
    await figma.clientStorage.deleteAsync("backend_url");
    const plugin_token = await getStoredPluginToken();
    const file_url = await getStoredFileUrl();
    const sort_method = await getStoredSortMethod();
    postAuthState(Boolean(plugin_token), file_url, sort_method);
  }
  async function savePluginToken(plugin_token) {
    const trimmed_token = plugin_token.trim();
    if (!trimmed_token.startsWith("fc_")) {
      figma.ui.postMessage({
        type: "connect_error",
        message: "Token must start with fc_. Copy your plugin token from your web profile."
      });
      return;
    }
    const verify_url = deriveVerifyUrl(CLASSIFY_API_URL);
    let response;
    try {
      response = await fetch(verify_url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${trimmed_token}`
        }
      });
    } catch {
      figma.ui.postMessage({
        type: "connect_error",
        message: "Could not reach Comment Sort. Check your connection and try again."
      });
      return;
    }
    if (!response.ok) {
      const body_text = await response.text();
      figma.ui.postMessage({
        type: "connect_error",
        message: formatBackendErrorMessage(body_text, response.status)
      });
      return;
    }
    const payload = await response.json();
    const prefix = extractVerifyPrefix(payload);
    await figma.clientStorage.setAsync(PLUGIN_TOKEN_STORAGE_KEY, trimmed_token);
    const file_url = await getStoredFileUrl();
    const sort_method = await getStoredSortMethod();
    postAuthState(true, file_url, sort_method);
    figma.ui.postMessage({
      type: "connect_success",
      prefix
    });
  }
  async function clearPluginToken() {
    await figma.clientStorage.deleteAsync(PLUGIN_TOKEN_STORAGE_KEY);
    const file_url = await getStoredFileUrl();
    const sort_method = await getStoredSortMethod();
    postAuthState(false, file_url, sort_method);
  }
  async function savePluginSettings(file_url, sort_method) {
    await figma.clientStorage.setAsync(FILE_URL_STORAGE_KEY, file_url.trim());
    await figma.clientStorage.setAsync(SORT_METHOD_STORAGE_KEY, sort_method);
  }
  async function getStoredPluginToken() {
    const stored_token = await figma.clientStorage.getAsync(
      PLUGIN_TOKEN_STORAGE_KEY
    );
    if (typeof stored_token !== "string" || stored_token.trim().length === 0) {
      return null;
    }
    return stored_token.trim();
  }
  function deriveVerifyUrl(classify_url) {
    if (classify_url.endsWith("/api/classify")) {
      return classify_url.replace(/\/api\/classify$/, "/api/plugin/verify");
    }
    return classify_url.replace(/\/api\/classify\/?$/, "/api/plugin/verify");
  }
  async function getStoredFileUrl() {
    const stored = await figma.clientStorage.getAsync(FILE_URL_STORAGE_KEY);
    if (typeof stored !== "string" || stored.trim().length === 0) {
      return null;
    }
    return stored.trim();
  }
  async function getStoredSortMethod() {
    const stored = await figma.clientStorage.getAsync(SORT_METHOD_STORAGE_KEY);
    if (stored === "ai" || stored === "heuristic") {
      return stored;
    }
    return "heuristic";
  }
  function postAuthState(connected, file_url, sort_method) {
    figma.ui.postMessage({
      type: "auth_state",
      connected,
      file_url,
      sort_method
    });
  }
  function extractVerifyPrefix(payload) {
    if (typeof payload !== "object" || payload === null) {
      return "fc_";
    }
    const record = payload;
    if (typeof record.prefix === "string" && record.prefix.length > 0) {
      return record.prefix;
    }
    return "fc_";
  }
  function formatBackendErrorMessage(raw_error_body, status) {
    const code = extractBackendErrorCode(raw_error_body);
    const backend_message = extractBackendErrorMessage(raw_error_body);
    if (status === 401 || code === "unauthorized") {
      return "Your plugin token is missing, invalid, or revoked. Copy a new one from your web profile.";
    }
    if (status === 403 || code === "email_not_confirmed") {
      return "Confirm your email on the web app, then try again.";
    }
    if (code === "missing_figma_token" || code === "missing_llm_key") {
      return "Save your credentials on your web profile before running analysis.";
    }
    if (code === "invalid_figma_token") {
      return "Your Figma token was rejected. Update your personal access token on your web profile.";
    }
    if (code === "invalid_credentials") {
      return "Your model API key was rejected. Update it on your web profile.";
    }
    if (code === "rate_limited" || code === "provider_rate_limited") {
      return "Too many requests. Wait a moment and try again.";
    }
    if (code === "provider_unavailable") {
      return "AI provider is unavailable right now. Try again, or switch to keyword sort.";
    }
    if (backend_message.length > 0) {
      return backend_message;
    }
    return `Backend request failed (${status}).`;
  }
  function extractBackendErrorCode(raw_error_body) {
    try {
      const parsed = JSON.parse(raw_error_body);
      if (typeof parsed === "object" && parsed !== null && "error" in parsed && typeof parsed.error === "object") {
        const error_field = parsed.error;
        if (error_field && typeof error_field.code === "string") {
          return error_field.code;
        }
      }
    } catch {
      return null;
    }
    return null;
  }
  function isUiMessage(value) {
    if (typeof value !== "object" || value === null) {
      return false;
    }
    if (!("type" in value)) {
      return false;
    }
    const record = value;
    if (record.type === "save_token") {
      return typeof record.plugin_token === "string";
    }
    if (record.type === "save_settings") {
      return typeof record.file_url === "string" && (record.sort_method === "heuristic" || record.sort_method === "ai");
    }
    if (record.type === "clear_token") {
      return true;
    }
    if (record.type === "resize_ui") {
      return typeof record.height === "number";
    }
    if (record.type === "open_external") {
      return typeof record.href === "string";
    }
    if (record.type !== "run_analysis") {
      return false;
    }
    return record.output_format === "table" || record.output_format === "sticky_notes" || record.output_format === "csv";
  }
  function openExternal(href) {
    const parsed = safeParseHttpsUrl(href);
    if (!parsed) {
      return;
    }
    const host_allowed = parsed.hostname === "comment-sort.vercel.app" || parsed.hostname === "figcomment.vercel.app";
    const path_allowed = parsed.pathname === "/" || parsed.pathname === "/profile" || parsed.pathname === "/privacy";
    if (!host_allowed || !path_allowed) {
      return;
    }
    figma.openExternal(parsed.href);
  }
  function safeParseHttpsUrl(value) {
    const trimmed = value.trim();
    const match = trimmed.match(/^https:\/\/([^/?#]+)(\/[^?#]*)?/i);
    if (!match) {
      return null;
    }
    return {
      href: trimmed,
      hostname: (match[1] ?? "").toLowerCase(),
      pathname: match[2] ?? "/"
    };
  }
  function formatUnknownError(error) {
    if (error instanceof Error) {
      return error.message;
    }
    if (typeof error === "string") {
      return error;
    }
    if (typeof error === "object" && error !== null && "message" in error && typeof error.message === "string") {
      return error.message;
    }
    try {
      return `Unexpected error payload: ${JSON.stringify(error)}`;
    } catch {
      return "Unexpected error payload (non-serializable).";
    }
  }
  function extractBackendErrorMessage(raw_error_body) {
    try {
      const parsed = JSON.parse(raw_error_body);
      if (typeof parsed === "object" && parsed !== null && "error" in parsed && typeof parsed.error === "object") {
        const error_field = parsed.error;
        if (error_field && typeof error_field.message === "string") {
          return error_field.message;
        }
      }
    } catch {
    }
    return raw_error_body;
  }
})();
